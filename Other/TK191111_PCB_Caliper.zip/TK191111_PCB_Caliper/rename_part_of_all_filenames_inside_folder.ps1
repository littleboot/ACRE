﻿clear
echo "Rename all files in ""$PWD"""
Read-Host -Prompt "Press any key to continue or CTRL+C to quit" 
$oldName = Read-Host 'old name'
$newName = Read-Host 'new name'
Get-ChildItem -Filter “*$oldName*” -Recurse | Rename-Item -NewName {$_.name -replace $oldName, $newName }