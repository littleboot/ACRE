﻿$des = Read-Host 'Folder location to copy datasheets to'
$dsheetLinkList = Read-Host 'TXT file with list containing links to datasheet files'

$safe = Get-Content $dsheetLinkList 
$safe | ForEach-Object{
    #find drive-delimeter
    $first=$_.IndexOf(":\");
    if($first -eq 1){
        #stripe it
        $newdes=Join-Path -Path $des -ChildPath @($_.Substring(0,1)+$_.Substring(2))[0]
        }
    else{
        $newdes=Join-Path -Path $des -ChildPath $_
    }
    $folder=Split-Path -Path $newdes -Parent
    $err=0
    #check if folder exists"
    $void=Get-Item $folder -ErrorVariable err  -ErrorAction SilentlyContinue
    if($err.Count -ne 0){
        #create when it doesn't
        $void=New-Item -Path $folder -ItemType Directory -Force -Verbose
        }
    $void=Copy-Item -Path $_ -destination $newdes -Recurse -Container -Force -Verbose
    }